package com.example.dashboad_v1;

import android.app.Activity;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executor;

public class EPRegister extends Fragment {

    private static final String TAG = "EP Register ...";
    private static final String REQ = "This Field is Required";
    EditText name, email, mobile, password, dob, address;
    Button submit;
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    FirebaseAuth mAuth = FirebaseAuth.getInstance();

    Map<String, Object> profData = new HashMap<>();




    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_ep_register, container, false);
    }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        name = view.findViewById(R.id.editTextName);
        email = view.findViewById(R.id.editTextEmail);
        mobile = view.findViewById(R.id.editTextMobile);
        password = view.findViewById(R.id.editTextPassword);
        dob = view.findViewById(R.id.editTextDOB);
        address = view.findViewById(R.id.editTextAddress);

        submit = view.findViewById(R.id.btnCreateUser);

/*        profData.put("name",name.getText().toString());
        profData.put("number",mobile.getText().toString());
        profData.put("email",email.getText().toString());
        profData.put("address",address.getText().toString());
        profData.put("dob",dob.getText().toString());*/

        dob.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                if(count == 2){
                    dob.setText(dob.getText().toString().trim() + "/");
                }else if(count == 5){
                    dob.setText(dob.getText().toString().trim() + "/");
                }
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checkFields()){
                    createUser(email.getText().toString(),password.getText().toString());
//                addData(mAuth.getCurrentUser());
                    NavHostFragment.findNavController(EPRegister.this)
                            .navigate(R.id.action_EPRegister_to_EPLogin);
                }

            }
        });

    }

    void createUser(String email, String password){
        try{
            mAuth.createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener((Activity) getContext(), new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                // Sign in success, update UI with the signed-in user's information
                                Log.d(TAG, "createUserWithEmail:success");
                                profData.put("name",name.getText().toString());
                                profData.put("number",mobile.getText().toString());
                                profData.put("email",email);
                                profData.put("address",address.getText().toString());
                                profData.put("dob",dob.getText().toString());

                                try {
                                    db.collection("users")
                                            .document(mAuth.getCurrentUser().getUid().toString())
                                            .set(profData);
                                    Log.w("putting data","Done Data has been added " + mAuth.getCurrentUser().getUid().toString());
                                    Toast.makeText(getContext(), "Done!!!", Toast.LENGTH_SHORT).show();

                                }
                                catch (Exception e){
                                    e.printStackTrace();
                                    Toast.makeText(getContext(), "NOT Done!!!", Toast.LENGTH_SHORT).show();

                                }


                            } else {
                                // If sign in fails, display a message to the user.
                                Log.w(TAG, "createUserWithEmail:failure", task.getException());
                                Toast.makeText(getContext(), "User creation failed!",Toast.LENGTH_SHORT).show();

                            }
                        }
                    });
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    /*void addData(FirebaseUser user){
        profData.put("name",name.getText().toString());
        profData.put("number",mobile.getText().toString());
        profData.put("email",email.getText().toString());
        profData.put("address",address.getText().toString());
        profData.put("dob",dob.getText().toString());

        try {
            db.collection("users")
                    .document(user.getUid().toString())
                    .set(profData);
            Log.w("putting data","Done Data has been added " + user.getUid().toString());
            Toast.makeText(getContext(), "Done!!!", Toast.LENGTH_SHORT).show();

        }
        catch (Exception e){
            e.printStackTrace();
            Toast.makeText(getContext(), "NOT Done!!!", Toast.LENGTH_SHORT).show();

        }
    }*/

    private boolean checkFields(){
        //Name
        if(name.length() ==0){
            name.setError(REQ);
            return false;
        }

        //Email
        if(email.length()==0){
            email.setError(REQ);
            return false;
        } else if (!email.getText().toString().trim().matches("[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+")){
            email.setError("Invalid Email address");
            return false;
        }

        //Mobile
        if(mobile.length() == 0){
            mobile.setError(REQ);
            return false;
        } else if (!mobile.getText().toString().trim().matches("[0-9]{10}")){
            mobile.setError("Enter Valid Mobile Number");
            return  false;
        }

        //Address
        if(address.length() == 0){
            address.setError(REQ);
            return false;
        }

        //DOB
        if(dob.length() == 0){
            dob.setError("REQ");
            return false;
        } else if(!dob.getText().toString().trim().matches("[0-9]{2}[/][0-9]{2}[/][0-9]{4}")){
            dob.setError("Check Format dd/mm/yyyy");
            return false;
        }

        //Password
        if (password.length() == 0){
            password.setError("REQ");
            return false;
        } else if(!password.getText().toString().trim()
                .matches("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#&()–[{}]:;',?/*~$^+=<>]).{6,20}$")){
            password.setError("Password must contain lowercase, uppercase, symbol and number");
            return  false;
        }


        return true;

    }

}