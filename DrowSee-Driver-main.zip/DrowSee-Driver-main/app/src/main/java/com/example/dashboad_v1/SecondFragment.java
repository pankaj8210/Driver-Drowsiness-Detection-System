package com.example.dashboad_v1;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class SecondFragment extends Fragment {

    public Map<String, Object> user_info = new HashMap<String, Object>();
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
    TextView name, address, mobile, email, dob;


    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_second, container, false);
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        name = view.findViewById(R.id._name);
        address = view.findViewById(R.id._Address);
        mobile = view.findViewById(R.id._Mobile);
        email = view.findViewById(R.id._email);
        dob = view.findViewById(R.id._DOB);

        getData();


        view.findViewById(R.id.back).setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(SecondFragment.this)
                        .navigate(R.id.action_SecondFragment_to_FirstFragment);


            }
        });

        view.findViewById(R.id.edit).setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(SecondFragment.this)
                        .navigate(R.id.action_SecondFragment_to_profileEdit2);

                Bundle details = new Bundle();
                details.putString("mobile",mobile.getText().toString());
                details.putString("name",name.getText().toString());
                details.putString("email",email.getText().toString());
                details.putString("address",address.getText().toString());
                details.putString("dob",dob.getText().toString());
                getParentFragment().setArguments(details);


            }
        });

    }

    void getData(){
        try {

            DocumentReference docRef = db.collection("users").document(user.getUid().toString());
            docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                private static final String TAG = "Getting Data";

                @Override
                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                    if (task.isSuccessful()) {
                        DocumentSnapshot document = task.getResult();
                        if (document.exists()) {

                            user_info = task.getResult().getData();
                            System.out.print(user_info);
//                            Toast.makeText(getContext(), user_info.getClass().toString()
//                                    + "\n" + user_info.toString(), Toast.LENGTH_LONG).show();

                            name.setText(user_info.get("name").toString());
                            address.setText(user_info.get("address").toString());
                            mobile.setText(user_info.get("number").toString());
                            email.setText(user_info.get("email").toString());
                            dob.setText(user_info.get("dob").toString());


                            Log.d(TAG, "DocumentSnapshot data: " + document.getData());
                        } else {
                            Log.d(TAG, "No such document");//means user is new
                        }
                    } else {
                        Log.d(TAG, "get failed with ", task.getException());
                    }
                }
            });



        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}