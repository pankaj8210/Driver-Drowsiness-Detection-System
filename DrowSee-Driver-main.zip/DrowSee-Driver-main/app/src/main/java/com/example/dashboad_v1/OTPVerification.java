package com.example.dashboad_v1;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;


public class OTPVerification extends Fragment {

    private static final String TAG = "OTP";
    private EditText inputCode1, inputCode2, inputCode3, inputCode4, inputCode5, inputCode6;
    private String verificationID;
    private String mobileNum;


    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);



    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_otp_verification, container, false);
    }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);



        Bundle bundle = getParentFragment().getArguments();
        if(bundle!=null){
            mobileNum = bundle.getString("mobile");
            verificationID = bundle.getString("VerificationID");
//            Toast.makeText(getContext(), verificationID, Toast.LENGTH_LONG).show();
        }

        TextView textMobile = view.findViewById(R.id.textMobile);
        textMobile.setText(String.format(
                "+91-%s" ,mobileNum
        ));


        inputCode1 = view.findViewById(R.id.inputCode1);
        inputCode2 = view.findViewById(R.id.inputCode2);
        inputCode3 = view.findViewById(R.id.inputCode3);
        inputCode4 = view.findViewById(R.id.inputCode4);
        inputCode5 = view.findViewById(R.id.inputCode5);
        inputCode6 = view.findViewById(R.id.inputCode6);

        setupOTPInputs();

        final ProgressBar progressBar = view.findViewById(R.id.progressBar);
        final Button buttonVerify = view.findViewById(R.id.buttonVerify);




        view.findViewById(R.id.buttonVerify).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(inputCode1.getText().toString().trim().isEmpty()
                        || inputCode2.getText().toString().trim().isEmpty()
                        || inputCode3.getText().toString().trim().isEmpty()
                        || inputCode4.getText().toString().trim().isEmpty()
                        || inputCode5.getText().toString().trim().isEmpty()
                        || inputCode6.getText().toString().trim().isEmpty()) {
                    Toast.makeText(getContext(), "Please Enter Valid Code", Toast.LENGTH_SHORT).show();
                    return;
                }

                String code =
                        inputCode1.getText().toString() +
                                inputCode2.getText().toString() +
                                inputCode3.getText().toString() +
                                inputCode4.getText().toString() +
                                inputCode5.getText().toString() +
                                inputCode6.getText().toString();

                if(verificationID != null) {
                    progressBar.setVisibility(View.VISIBLE);
                    buttonVerify.setVisibility(View.INVISIBLE);
                    PhoneAuthCredential phoneAuthCredential = PhoneAuthProvider.getCredential(
                            verificationID,
                            code);

                    FirebaseAuth.getInstance().signInWithCredential(phoneAuthCredential)
                            .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    progressBar.setVisibility(View.GONE);
                                    buttonVerify.setVisibility(View.VISIBLE);


                                    if(task.isSuccessful()) {

                                        /*
                                        Check whether the user is a new user or a returning user, if the user is a returning user do not edit his profile
                                        but if the user is new just add create account in the database add his mobile numbers
                                        and initialize everything else to empty string
                                                */
                                        DocumentReference docRef = db.collection("users").document(user.getUid().toString());
                                        docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                            @Override
                                            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                                if (task.isSuccessful()) {
                                                    DocumentSnapshot document = task.getResult();
                                                    if (document.exists()) {
                                                        Log.d(TAG, "DocumentSnapshot data: " + document.getData());//means it is an existing user
                                                    } else {
                                                        Log.d(TAG, "No such document");//means user is new
                                                        addUser();
                                                    }
                                                } else {
                                                    Log.d(TAG, "get failed with ", task.getException());//means problem with querying firestore
                                                }
                                            }
                                        });

                                        Toast.makeText(getContext(), "Success", Toast.LENGTH_SHORT).show();
                                        NavHostFragment.findNavController(OTPVerification.this)
                                                .navigate(R.id.action_OTPVerification_to_FirstFragment);

                                    }else {
                                        Toast.makeText(getContext(), "The Verification Code Entered was Incorrect", Toast.LENGTH_SHORT).show();
                                    }

                                }
                            });

                }

            }
        });

        view.findViewById(R.id.textResendOTP).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PhoneAuthProvider.getInstance().verifyPhoneNumber(
                        "+91" + mobileNum,
                        60,
                        TimeUnit.SECONDS,
                        getActivity(),
                        new PhoneAuthProvider.OnVerificationStateChangedCallbacks(){

                            @Override
                            public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {
                            }

                            @Override
                            public void onVerificationFailed(@NonNull FirebaseException e) {
                                Toast.makeText(getContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                            }

                            @Override
                            public void onCodeSent(@NonNull String newVerificationID, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                                verificationID = newVerificationID;
                                Toast.makeText(getContext(), "OTP Sent", Toast.LENGTH_SHORT).show();
                            }
                        }
                );


            }
        });
    }


    private void setupOTPInputs() {
        inputCode1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(!s.toString().trim().isEmpty()) {
                    inputCode2.requestFocus();

                }

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        inputCode2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(!s.toString().trim().isEmpty()) {
                    inputCode3.requestFocus();

                }

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        inputCode3.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(!s.toString().trim().isEmpty()) {
                    inputCode4.requestFocus();

                }

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        inputCode4.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(!s.toString().trim().isEmpty()) {
                    inputCode5.requestFocus();

                }

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        inputCode5.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(!s.toString().trim().isEmpty()) {
                    inputCode6.requestFocus();

                }

            }

            @Override

            public void afterTextChanged(Editable s) {

            }
        });


    }

    private void addUser(){

        Map<String, Object> docData = new HashMap<>();
        docData.put("name","");
        docData.put("number",mobileNum);
        docData.put("email","");
        docData.put("address","");
        docData.put("dob","");

        try {
            db.collection("users")
                    .document(user.getUid().toString())
                    .set(docData);
            Log.w("putting data","DONE! " + user.getUid().toString());
        }
        catch (Exception e){
            e.printStackTrace();

        }

    }





}
