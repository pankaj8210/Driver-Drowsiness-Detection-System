package com.example.dashboad_v1;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;


public class ProfileEdit extends Fragment {

    Map<String, Object> profData = new HashMap<>();
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();


    EditText name,mobile,address,dob,email;
    public ProfileEdit() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_profile_edit, container, false);



    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        name = view.findViewById(R.id.ename);
        mobile = view.findViewById(R.id.emobile);
        address = view.findViewById(R.id.eaddress);
        dob = view.findViewById(R.id.edob);
        email = view.findViewById(R.id.eemail);

        Bundle details = getParentFragment().getArguments();
        name.setText(details.getString("name"));
        mobile.setText(details.getString("mobile"));
        address.setText(details.getString("address"));
        dob.setText(details.getString("dob"));
        email.setText(details.getString("email"));

        view.findViewById(R.id.back_profile).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                profData.put("name",name.getText().toString());
                profData.put("number",mobile.getText().toString());
                profData.put("email",email.getText().toString());
                profData.put("address",address.getText().toString());
                profData.put("dob",dob.getText().toString());

                if(checkFields()){
                    editProfile();
                }

            }
        });

    }



    void editProfile(){
        try {
            db.collection("users")
                    .document(user.getUid().toString())
                    .set(profData);
            Log.w("putting data","DONE! " + user.getUid().toString());
//            Toast.makeText(getContext(), "Done!!!", Toast.LENGTH_SHORT).show();
            NavHostFragment.findNavController(ProfileEdit.this)
                    .navigate(R.id.action_profileEdit2_to_SecondFragment);
        }
        catch (Exception e){
            e.printStackTrace();
//            Toast.makeText(getContext(), "NOT Done!!!", Toast.LENGTH_SHORT).show();

        }

    }

    private boolean checkFields(){

        //Email
        if(!email.getText().toString().trim().matches("[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+")){
            email.setError("Invalid Email address");
            return false;
        }

        //Mobile
        if(!mobile.getText().toString().trim().matches("[0-9]{10}")){
            mobile.setError("Enter Valid Mobile Number");
            return  false;
        }

        //Address

        //DOB
        if(!dob.getText().toString().trim().matches("[0-9]{2}[/][0-9]{2}[/][0-9]{4}")){
            dob.setError("Check Format dd/mm/yyyy");
            return false;
        }


        return true;

    }

}