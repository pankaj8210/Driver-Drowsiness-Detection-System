    package com.example.dashboad_v1;

import android.app.Activity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;


public class EPLogin extends Fragment {

    private static final String TAG = "LOGIN ...";
    EditText email, password;
    ImageView toOTP;
    TextView toReg, forgotPassword;
    Button btnLogin;

    String _email,_password;

    FirebaseFirestore db = FirebaseFirestore.getInstance();
    FirebaseAuth mAuth = FirebaseAuth.getInstance();
    FirebaseUser mUser = mAuth.getCurrentUser();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(mUser != null){
            NavHostFragment.findNavController(EPLogin.this)
                    .navigate(R.id.action_EPLogin_to_FirstFragment);
        }

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_ep_login, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        email = view.findViewById(R.id.editTextEmail);
        password = view.findViewById(R.id.editTextPassword);
        btnLogin = view.findViewById(R.id.btnLoginUser);
        toReg = view.findViewById(R.id.toRegister);
        toOTP = view.findViewById(R.id.toOTP);
        forgotPassword = view.findViewById(R.id.forgotPass);


        toOTP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NavHostFragment.findNavController(EPLogin.this)
                        .navigate(R.id.action_EPLogin_to_OTPLogin);
            }
        });

        forgotPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth auth = FirebaseAuth.getInstance();
                String emailAddress = email.getText().toString().trim();

                if(TextUtils.isEmpty(emailAddress)){
                    email.setError("Enter email");
                } else if(!emailAddress.matches("[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+")){
                    email.setError("Invalid Email");

                }else {
                    auth.sendPasswordResetEmail(emailAddress)
                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if (task.isSuccessful()) {
                                        Log.d(TAG, "Email sent.");
                                        Toast.makeText(getContext(), "Email Sent", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });
                }


            }
        });

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //login(email.getText().toString(),password.getText().toString());
                _email = email.getText().toString();
                _password = password.getText().toString();

                if(_password != null && _email!=null ){
                    mAuth.signInWithEmailAndPassword(_email,_password)
                            .addOnCompleteListener((Activity) getContext(), new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (task.isSuccessful()) {
                                        // Sign in success, update UI with the signed-in user's information
                                        Log.d(TAG, "signInWithEmail:success");
                                        FirebaseUser user = mAuth.getCurrentUser();
                                        NavHostFragment.findNavController(EPLogin.this)
                                                .navigate(R.id.action_EPLogin_to_FirstFragment);


                                    } else {
                                        // If sign in fails, display a message to the user.
                                        Log.w(TAG, "signInWithEmail:failure", task.getException());
                                        Toast.makeText(getContext(), "Wrong username or password", Toast.LENGTH_SHORT).show();

                                    }
                                }
                            });
                }
                else{

                }

            }
        });

        toReg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NavHostFragment.findNavController(EPLogin.this)
                        .navigate(R.id.action_EPLogin_to_EPRegister);
            }
        });

    }
    void login(String email, String password){
//         mAuth.signInWithEmailAndPassword(email, password)
//                    .addOnCompleteListener(getContext(), new OnCompleteListener<AuthResult>() {
//                        @Override
//                        public void onComplete(@NonNull Task<AuthResult> task) {
//                            if (task.isSuccessful()) {
//                                // Sign in success, update UI with the signed-in user's information
//                                Log.d(TAG, "signInWithEmail:success");
//                                FirebaseUser user = mAuth.getCurrentUser();
//
//                            } else {
//                                // If sign in fails, display a message to the user.
//                                Log.w(TAG, "signInWithEmail:failure", task.getException());
//
//
//                            }
//                        }
//                    });



    }

}